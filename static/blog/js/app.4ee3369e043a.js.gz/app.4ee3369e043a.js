$(function(){
   	// var s = skrollr.init();
   	// alert("hi");
   	$("introtext").typed({
            strings: ["^500 Wait! wanna know why you would log in?",
            		"Well",
            		"The answer is simple",
            		"Or is it?",
            		"i just wanna blog",
            		"LOG IN!!",
            		"Whats's Blogger for then?",
            		"Does Blogger allow you to make friends?",
            		"Just log in"],
            typeSpeed: 100,
            cursorChar: ""
        });


});